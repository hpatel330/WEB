/********************************************************************************
*  WEB322 – Assignment 03
* 
*  I declare that this assignment is my own work in accordance with Seneca's
*  Academic Integrity Policy:
* 
*  https://www.senecacollege.ca/about/policies/academic-integrity-policy.html
* 
*  Name: Hetvi Nileshkumar Patel Student ID: 167787217 Date: 05/07/24
*
*  Published URL: https://github.com/hpatel330/WEB
*
********************************************************************************/

const express = require('express');
const path = require('path');
const legoData = require("./modules/legoSets");

const app = express();
const HTTP_PORT = process.env.PORT || 3000;  // Changed port to 3000

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Body parsing middleware for POST requests if needed
app.use(express.urlencoded({ extended: true }));

// Routes
app.get('/', (req, res) => {
    res.render('home');
});

app.get('/about', (req, res) => {
    res.render('about');
});

app.get('/lego/sets', async (req, res) => {
    try {
        let sets;
        if (req.query.theme) {
            sets = await legoData.getSetsByTheme(req.query.theme);
        } else {
            sets = await legoData.getAllSets();
        }
        res.render('sets', { sets: sets });
    } catch (err) {
        res.status(404).send(err);
    }
});

app.get('/lego/sets/:set_num', async (req, res) => {
    try {
        let set = await legoData.getSetByNum(req.params.set_num);
        if (!set) {
            res.status(404).render('404');
            return;
        }
        res.render('set', { set: set });
    } catch (err) {
        res.status(404).render('404');
    }
});

// Handle 404 - Keep this as the last route
app.use((req, res) => {
    res.status(404).render('404');
});

// Start the server
legoData.initialize().then(() => {
    app.listen(HTTP_PORT, () => {
        console.log(`Server is listening on port ${HTTP_PORT}`);
    });
});
